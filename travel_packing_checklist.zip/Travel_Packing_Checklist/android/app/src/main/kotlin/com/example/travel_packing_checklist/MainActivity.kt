package com.example.travel_packing_checklist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
